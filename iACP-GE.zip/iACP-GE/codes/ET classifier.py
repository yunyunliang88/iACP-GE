from sklearn.metrics import accuracy_score
from sklearn.metrics import roc_auc_score
from sklearn.metrics import matthews_corrcoef
from sklearn.metrics import roc_curve
from sklearn.model_selection import KFold
from sklearn.model_selection import LeaveOneOut
from sklearn.metrics import make_scorer
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import cross_validate
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.svm import SVC
import pandas as pd
import numpy as np


dataset=pd.read_excel('XXX.xlsx',header=None)
dataset=np.matrix(dataset)

X=dataset[:,:-1]
Y=dataset[:,-1]

clf=ExtraTreesClassifier(random_state=0)
def GetSn(y_true,y_pred):
    confmatrix=confusion_matrix(y_true,y_pred)
    tn=confmatrix[0][0]
    fp=confmatrix[0][1]
    fn=confmatrix[1][0]
    tp=confmatrix[1][1]
    sn=tp/(tp+fn)
    mcc=matthews_corrcoef(y_true,y_pred)
    tpr,fpr,thresholds=roc_curve(y_true,y_pred)
    return sn


def GetSp(y_true,y_pred):
    confmatrix=confusion_matrix(y_true,y_pred)
    tn=confmatrix[0][0]
    fp=confmatrix[0][1]
    fn=confmatrix[1][0]
    tp=confmatrix[1][1]
    sp=tn/(tn+fp)
    return sp


def GetMcc(y_true,y_pred):
    mcc=matthews_corrcoef(y_true,y_pred)
    return mcc

cv=KFold(n_splits=5, shuffle=True, random_state=1)
# cv_loo=LeaveOneOut()

sn=make_scorer(GetSn,greater_is_better=True)
sp=make_scorer(GetSp,greater_is_better=True)
mcc=make_scorer(GetMcc,greater_is_better=True)
score=cross_validate(clf,X,Y,scoring={'acc':'accuracy','auc':'roc_auc','sn':sn,'sp':sp,'mcc':mcc},
                     return_train_score=False,cv=cv)
# score=cross_validate(clf,X,Y,scoring={'acc':'accuracy','auc':'roc_auc','sn':sn,'sp':sp,'mcc':mcc},
#                      return_train_score=False,cv=cv_loo)

print(score['test_acc'].mean())
print(score['test_auc'].mean())
print(score['test_sn'].mean())
print(score['test_sp'].mean())
print(score['test_mcc'].mean())
