% "Seq" is the sequence of a peptide sample
% "feature" is the generated feature vector corresponding to the given peptide sample 
% Seq = 'GLWSKIKEVGKEAAKAAAKAAGKAALGAVSEAV';

tt=fastaread('C:XXX\acp240.txt');

value_na = cell(1,20);
value_na{1} = 'A'; value_na{2} = 'G'; value_na{3} = 'I'; value_na{4} = 'L';
value_na{5} = 'P'; value_na{6} = 'V'; value_na{7} = 'F'; value_na{8} = 'W';
value_na{9} = 'Y'; value_na{10} = 'D'; value_na{11} = 'E'; value_na{12} = 'R';
value_na{13} = 'H'; value_na{14} = 'K'; value_na{15} = 'S'; value_na{16} = 'T';
value_na{17} = 'C'; value_na{18} = 'M'; value_na{19} = 'N'; value_na{20} = 'Q';

Pro = [90.12 75.08 132.21 132.21 116.16 118.18 166.22 205.26 182.22 134.13 148.16 176.26 156.19 148.24 106.12 120.15 122.19 150.25 133.15 147.18;
       7.11 5.21 11.90 11.90 9.71 10.31 14.31 17.30 14.82 9.13 10.73 14.59 12.10 13.20 7.62 9.22 8.20 11.39 9.62 11.21;
       14.35 10.52 23.00 23.00 18.23 20.12 24.12 28.22 25.44 18.00 20.89 28.36 21.55 26.04 15.68 18.56 15.43 21.19 18.78 21.66;
       7.58 5.44 12.86 12.86 10.34 11.10 15.10 18.11 15.56 9.49 11.25 15.50 12.59 14.25 8.03 9.80 9.23 12.75 10.04 11.80;
       2 2 2 2 2 2 2 3 3 4 4 4 4 2 4 4 2 2 4 4;
       24 19 61 63 51 43 131 195 157 63 85 139 106 98 36 43 36 74 63 85;
       16 13 37 38 27 27 68 95 82 38 50 79 55 57 23 27 23 44 38 50;
       0.576 0.828 0.557 0.500 0.651 0.410 0.831 0.852 0.787 0.708 0.770 0.863 0.644 0.836 0.652 0.450 0.668 0.810 0.734 0.787;
       3.794 2.870 2.926 2.926 2.001 3.150 2.456 3.198 3.446 4.320 4.068 8.560 3.857 6.438 4.875 4.508 4.875 3.032 5.574 5.271;];

for ii = 1:size(Pro,1)
    Pro(ii,:)=(Pro(ii,:)-min(Pro(ii,:)))/(max(Pro(ii,:))-min(Pro(ii,:)));
end

for i=1:240
SSS{1,i}=tt(i).Sequence;
end

for t=1:240
    Seq=SSS{1,t};

value_matrix = zeros(size(Pro,1),length(Seq));
    for ii = 1:size(Pro,1)
        for jj = 1:20
             value_matrix(ii,strfind(Seq,value_na{jj})) = Pro(ii,jj);
        end
    end
value_matrix = value_matrix';
matrix{1,t}=value_matrix;
end


