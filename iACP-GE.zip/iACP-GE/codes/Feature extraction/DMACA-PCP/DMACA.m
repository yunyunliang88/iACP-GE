
P1=load('acp240.mat');
dmaca10=zeros(240,45);
for t=1:240
    P=cell2mat(P1.matrix(1,t));
    [L,n]=size(P);
    ls=L-10+1; %2,3,4,5,6,7,8,9,10
    F=zeros(ls,9);
    C=zeros(1,45);
    c=0;
    s=0;
         
        for i=1:9
               for j=1:ls
                   for k=-9:0 %-1,-2,-3,-4,-5,-6,-7,-8,-9 
                      F(j,i)=F(j,i)+P(j-k,i)/10;  %2,3,4,5,6,7,8,9,10
                   end
               end
        end
     
     for i=1:9
           for k=i:9
              c=c+1;
               for j=1:ls
                 C(1,c)= C(1,c)+((P(j,i)-F(j,i))*(P(j,k)-F(j,k)))/ls;
               end 
           end
     end
     
    for i=1:9
           for k=i:9
                   s=s+1;
             dmaca10(t,s)=C(1,s);
           end
    end
    
     
end

