
tt=fastaread('C:XXX\acp240.txt'); 
for i=1:240
SSS{1,i}=tt(i).Sequence;
end
for t=1:240
    S=SSS{1,t};
    L=length(S);
    for k=1:5
    NC(k)=S(k);
    end
    m=6;
    for j=(L-4):L
    NC(m)=S(j);
    m=m+1;
    end
SSS{1,t}=NC;
end



