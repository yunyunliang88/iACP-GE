% tt=fastaread('C:XXX\acp240.txt');
% for i=1:240  
% SSS{1,i}=tt(i).Sequence;
% end
k=5; % default
l=10-k+1;
E=zeros(240,l*5); 
for t=1:240
    S=SSS{1,t};
    L=length(S);
    C1={'A','G','I','M','L','V'};
    C2={'F','W','Y'};
    C3={'H','K','R'};
    C4={'D','E'};
    C5={'C','N','P','Q','S','T'};
for m=1:l
    a=0;
    b=0;
    c=0;
    d=0;
    e=0;
for i=m:m+k-1
    for j=1:length(C1)
        if S(i)==C1{j}
            a=a+1;
        end
    end
end
E(t,(m-1)*5+1)=a/k;
for i=m:m+k-1
    for j=1:length(C2)
        if S(i)==C2{j}
            b=b+1;
        end
    end
end
E(t,(m-1)*5+2)=b/k;
for i=m:m+k-1
    for j=1:length(C3)
        if S(i)==C3{j}
            c=c+1;
        end
    end
end
E(t,(m-1)*5+3)=c/k;
for i=m:m+k-1
    for j=1:length(C4)
        if S(i)==C4{j}
            d=d+1;
        end
    end
end
E(t,(m-1)*5+4)=d/k;
for i=m:m+k-1
    for j=1:length(C5)
        if S(i)==C5{j}
            e=e+1;
        end
    end
end
E(t,(m-1)*5+5)=e/k;
end
end

