import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings("ignore")


dataset=pd.read_excel('XXX.xlsx',header=None)
dataset=np.matrix(dataset)

X=dataset[:,:-1]
label=dataset[:,-1]

def GBDT():
    from sklearn.feature_selection import SelectFromModel
    from sklearn.ensemble import GradientBoostingClassifier
    clf=GradientBoostingClassifier(random_state=10).fit(X,label)
    model=SelectFromModel(clf,prefit=True)
    newMat=model.transform(X)
    pd.DataFrame(newMat).to_excel('GBDTe.xlsx',header=False,index=False)

if __name__ == '__main__':
       GBDT()
